package com.orgchart.orgchart;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OrgchartApplicationTests {

	@Test
	void contextLoads() {
	}

}
