function showDepartmentStructure(departmentName){
	location.href = departmentName+"/structure";
}